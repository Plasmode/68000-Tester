;boot from MBR of CF disk
CFdata	equ $ffffff00
CFerr	equ $100002
CFsectcnt	equ $100004
CF07	equ $100006
CF815	equ $100008
CF1623	equ $10000A
CF2427	equ $10000C
CFstat	equ $10000E
PageFF	equ $10003E
SerRx	equ $ffffff83
SerTx	equ $ffffff83
SerStat	equ $ffffff81
         org $0
	dc.l $ffff000
	dc.l $8
	lea $ffffff0e,a1
chkbusy:	
	btst.b #7,(a1)		;check busy flag
	bne.s chkbusy
	move.b #$20,(a1)		;read CF MBR
chkdrq:	
	btst.b #3,(a1)		;check drq bit
	beq.s chkdrq
	lea $100,a0
	move.w #$ff,d0		;loop 256 times
getCFdata:	
	move.w CFdata,(a0)+	;move CF data to $100
	dbra d0,getCFdata
	bra $100
	end 0
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;	
         lea hello_,a1              ;send Hello World message
nxtByte:         
         move.b (a1)+,d0
         beq msgdone
         jsr cout
         bra nxtByte
msgdone:

         nop                        ;spin here forever
         bra msgdone
cout:
;send byte in d0 to serial port
	btst.b #1,SerStat			;check for TxEmpty
	beq.s cout
	move.b d0,SerTx
	rts
hello_: dc.b 10,13,'Hello world'
         dc.b 10,13,'this is a test',10,13 
         dc.b 10,13,'1234567890abcdefghijklmnopqrstuvwxyz',10,13
         dc.b 'ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()',10,13,0         
         
         dcb.w $400,$5a     
         
         end $400     








*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
