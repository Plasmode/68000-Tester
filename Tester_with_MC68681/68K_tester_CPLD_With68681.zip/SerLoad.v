module SerLoad( 
    input [4:0]addr, 
    output reg [15:0]ROMdata);     
    always @(*)
    begin
    //embedded 6502 instruction in ROM
        case(addr)
									
        5'b00000: ROMdata = 16'h0000; // 
        5'b00001: ROMdata = 16'h0000; 
        5'b00010: ROMdata = 16'h0000; // 
        5'b00011: ROMdata = 16'h0008; // 
        5'b00100: ROMdata = 16'h11fc; // 
        5'b00101: ROMdata = 16'h0000; // 
        5'b00110: ROMdata = 16'hff13; // 
        5'b00111: ROMdata = 16'h11fc; // 
        5'b01000: ROMdata = 16'h00ff; // 
        5'b01001: ROMdata = 16'hff13; // 
        5'b01010: ROMdata = 16'h43f9; // 
        5'b01011: ROMdata = 16'h0000; // 
        5'b01100: ROMdata = 16'h0034; // 
        5'b01101: ROMdata = 16'h323c; //  
        5'b01110: ROMdata = 16'h0100; // 
        5'b01111: ROMdata = 16'h0838; // 
        5'b10000: ROMdata = 16'h0000; //       
        5'b10001: ROMdata = 16'hff11; // 
        5'b10010: ROMdata = 16'h67f8; // 
        5'b10011: ROMdata = 16'h12f8; //   
        5'b10100: ROMdata = 16'hff13; //  
        5'b10101: ROMdata = 16'h51c9; // 
        5'b10110: ROMdata = 16'hfff2; // 
        5'b10111: ROMdata = 16'h4238; // 
        5'b11000: ROMdata = 16'hff1f; // 
        5'b11001: ROMdata = 16'h4e71; //
        5'b11010: ROMdata = 16'hxxxx; // 
        5'b11011: ROMdata = 16'hxxxx; // 
        5'b11100: ROMdata = 16'hxxxx; // 
        5'b11101: ROMdata = 16'hxxxx; // 
        5'b11110: ROMdata = 16'hxxxx; // 
        5'b11111: ROMdata = 16'hxxxx; // 

            
        endcase
    end
endmodule