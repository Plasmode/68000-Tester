;serial loader
;expect 256 bytes of binary data
;load into $80000
;jump to $80000 after 256 bytes received
SerRx	equ $ffffff13
SerTx	equ $ffffff13
SerStat	equ $ffffff11
RomDis	equ $ffffff1f			;write disable ROM
	org $0
	dc.l 0				;stack
	dc.l start
start:
	move.b #0,SerTx			;send out prompt
	move.b #$ff,SerTx			;toggle Tx
	lea RAMhere,a1			;move a block of data to $34 (after end of ROM)
	move.w #$100,d1
loadloop:
	btst.b #0,SerStat			;check for RxRdy
	beq.s loadloop
	move.b SerRx,(a1)+
	dbra d1,loadloop
	clr.b RomDis
	nop
RAMhere:					;RAM program starts here	
	
	end $0	




*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
