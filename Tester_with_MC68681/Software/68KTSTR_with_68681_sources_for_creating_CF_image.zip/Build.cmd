@echo off
setlocal

set PATH=c:\Srec_cat;%PATH%

:build

srec_cat -generate 0x0 0x100000 --constant 0x00 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x0 0x200 MBRload.bin -binary -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x1B8 0x200 ptbl.bin -binary -offset 0x1B8 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x400 0x4000 68KMon.bin -binary -offset 0x400 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x4000 0x8000 tutor_easy68k.bin -binary -offset 0x4000 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x8000 0xC000 .\EhBASIC\Basic68s3.52.bin -binary -offset 0x8000 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0xC000 0x12000 .\CPM68K\ccpbdos.bin -binary -offset 0xC000 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x12000 0x17000 .\CPM68K\tstrbios.bin -binary -offset 0x12000 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x17000 0x56E00 .\CPM68K\essential.bin -binary -offset 0x17000 -o temp.dat -binary

copy /b temp.dat image.img || exit /b


goto :eof
