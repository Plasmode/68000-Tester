;CF loader
;this program is for MBR of CF disk
;this is for 68KTSTR with 68681 for serial port
;It loads programs from CF LBA1 to LBA20 to $200 and then jump to $400
;LBA1 is blank, program starts from LBA2
;68KMon is loaded from $400 up to $3FFF; 
;other applications are loaded from CF disk when invoked
; TUTOR is located from LBA $20 to LBA $3F
; EhBASIC is located from LBA $40 to LBA $5F
; CP/M68K is located from LBA $60 to $1FF

CFdata   equ $FFFFFF20       * CF data register
CFerr    equ $FFFFFF22       * CF error reg
CFsectcnt equ $FFFFFF24      * CF sector count reg
CF07     equ $FFFFFF26       * CF LA0-7
CF815    equ $FFFFFF28       * CF LA8-15
CF1623   equ $FFFFFF2A       * CF LA16-23
CF2427   equ $FFFFFF2C       * CF LA24-27
CFstat   equ $FFFFFF2E       * CF status/command reg
RomDis	equ $ffffff1f			;write disable ROM
;
DUART	equ $FFFFFF00	* base address of 68692 DUART
MRA	equ $FFFFFF01	* mode reg A
SRA	equ $FFFFFF03	* status A (read)
CSRA	equ $FFFFFF03	* clock select reg (write)
CRA	equ $FFFFFF05	* command register (write only)
;;RHRA	equ $FFFFFF07	* Rx Hold reg A (read)
THRA	equ $FFFFFF07	* Tx Holding reg (write)
;;IPCR	equ $FFFFFF09	* Input port change reg (read)
ACR	equ $FFFFFF09	* Aux control reg (write)
;;ISRD	equ $FFFFFF0B	* interrupt status reg (read)
IMRD	equ $FFFFFF0B	* interrupt mask reg (write)			
;;CTU	equ $FFFFFF0D	* Counter/timer upper (read)
;;CTL	equ $FFFFFF0F	* counter/timer lower (read)
CTUR	equ $FFFFFF0D	* Counter/timer preload upper (write)
CTLR	equ $FFFFFF0F	* counter/timer preload lower (write)
;;MR1B	equ $FFFFFF11	* mode reg B
;;SRB	equ $FFFFFF13	* status reg B
;;RHRB	equ $FFFFFF17	* Rx holding reg B
IVRD	equ $FFFFFF19	* interrupt vector reg
STOPCTR	equ $FFFFF01F	* stop counter command reg (read)
;;STARTCTR equ $FFFFFF1D	* start counter command reg (read)
SETOPR	equ $FFFFFF1D	* bit set output register bits (write)
CLROPR	equ $FFFFFF1F	* bit clear output register (write)
OPCR	equ $FFFFFF1B	* output configuration register(write)

	org $34
	nop
	nop
	lea $ffff0,sp			;set up stack pointer
	bsr iDUART			;set up 68681
	move.b #'X',d0
	bsr cout		
	move.b #$e0,CF2427		;set up LBA mode
	move.b #0,CF1623			;set to LBA 1
	move.b #0,CF815
	lea $200,a3			;LBA1 to RAM $200; LBA2 to RAM $400, so on
	move.b #1,d5			;d5 keep track of the sector value	
	clr.w d4				;d4 keeps track of checksum
spin:	
	move.b d5,CF07
	move.b #1,CFsectcnt		;read one sector       
	move.b #$20,CFstat		;read sector command
chkdrq:
         btst.b #3,CFstat          		;check data request bit set before reading
         beq chkdrq 
         move.w #$ff,d3            		;read 512 bytes
readCF1:
         move.w CFdata,d0
	add.w d0,d4			;accumulate checksum
	move.w d0,(a3)+           		;get data and put in destination
         dbra d3,readCF1
	addq.b #1,d5
	cmp.b #$21,d5			;load LBA 1- LBA $21, containing 68KMon
	bne.s spin
	move.b #'Z',d0
	bsr cout
	move.w d4,$ffedc			;top of 68KMon variable area
	move.b d4,d0			;print out the checksum
	bsr hex2asc
	bsr cout				;display the LSB of checksum
	ror.w #8,d0			;display the MLB of checksum
	bsr cout
	ror.w #8,d4
	move.b d4,d0
	bsr hex2asc
	bsr cout				;display MUB of checksum
	ror.w #8,d0			;display MSB of checksum
	bsr cout	
	jmp $400	
* hex to ascii
* byte value in d0.b is converted to ascii in d0.w
hex2asc:
	movem.l d1,-(sp)
	move.b d0,d1
	lsr.b #4,d1		* get the high nibble first
	add.b #$30,d1
	cmp.b #'9',d1		* '0' to '9'
	bls hex2asc7
	add.b #7,d1		* or 'A' to 'F'
hex2asc7:
	lsl.w #8,d1		* put result in high byte
	move.b d0,d1		* work on the low nibble
	and.b #$F,d1		* isolate low nibble
	add.b #$30,d1
	cmp.b #'9',d1		* '0' to '9'
	bls hex2asc8
	add.b #7,d1		* or 'A' to 'F'
hex2asc8:
	move.l d1,d0		* done
	movem.l (sp)+,d1
	rts
         
cout:
;send regD0 to serial port
	btst.b #2,SRA
	beq cout
	move.b d0,THRA
	rts

* initialize the DUART 68692, only lower byte is connected to data bus d0-d7
**HH 10/25/17 enable hardware handshake of serial port A
iDUART:
	move.b #$13,MRA		* write to MR1A as follow:
			**HH RxRTS, RxRDY int, Char error, no parity, 8 bits
	move.b #$07,MRA		* now write to MR2A as follow:
			**HH normal, no TxRTS, CTS, 1 stop
	move.b #$0,IMRD		* mask off interrupt
	move.b #$81,IVRD	* vector number 0x81 is where DUART ISR is located
	move.b #0,OPCR		* make output register general purpose
	move.b #$ff,SETOPR	* clear display
	move.b #$7e,CLROPR	* drive the value '0' on a 7-seg display
	move.b #$70,ACR		* clear ACR[7] bit, timer mode, 16x prescaler
	move.b #$80,CTLR	* to get 10ms interrupt, timer preload value is 0x480
	move.b #$4,CTUR
	move.b #$CC,CSRA	* 38.4K baud
	move.b STOPCTR,d0	* read clear the interrupt bit associated with timer
;	move.b #$A,CRA		* disable Chan A transmit and receive
	move.b #$5,CRA		* enable Chan A transmit and receive
	rts

         
CFbuf:
	end 0
	


















*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
