;CF loader
;this program is for MBR of CF disk
;It loads program from CF LBA1 to LBA18 to $400 and then jump to $400
CFdata   equ $FFFFFF20       * CF data register
CFerr    equ $FFFFFF22       * CF error reg
CFsectcnt equ $FFFFFF24      * CF sector count reg
CF07     equ $FFFFFF26       * CF LA0-7
CF815    equ $FFFFFF28       * CF LA8-15
CF1623   equ $FFFFFF2A       * CF LA16-23
CF2427   equ $FFFFFF2C       * CF LA24-27
CFstat   equ $FFFFFF2E       * CF status/command reg
SerData	equ $ffffff13
SerStat	equ $ffffff11
RomDis	equ $ffffff1f			;write disable ROM

	org $34
	nop
	nop
	lea $ffff0,sp			;set up stack pointer
	move.b #'X',d0
	bsr cout	
	move.b #$e0,CF2427		;set up LBA mode
	move.b #0,CF1623			;set to LBA 2
	move.b #0,CF815
	lea $400,a3
;skip over LBA1, monitor program stored start from LBA2	
	move.b #2,d5			;d5 keep track of the sector value	
	clr.w d4				;d4 keeps track of checksum
spin:	
	move.b d5,CF07
	move.b #1,CFsectcnt		;read one sector       
	move.b #$20,CFstat		;read sector command
chkdrq:
         btst.b #3,CFstat          		;check data request bit set before reading
         beq chkdrq 
         move.w #$ff,d3            		;read 512 bytes
readCF1:
         move.w CFdata,d0
	add.w d0,d4			;accumulate checksum
	move.w d0,(a3)+           		;get data and put in destination
         dbra d3,readCF1
	addq.b #1,d5
	cmp.b #$41,d5			;load LBA 2-$40, 68KMon, TUTOR
	bne.s spin
	move.b #'Z',d0
	bsr cout
	move.w d4,$ffedc			;top of 68KMon variable area
	move.b d4,d0			;print out the checksum
	bsr hex2asc
	bsr cout				;display the LSB of checksum
	ror.w #8,d0			;display the MLB of checksum
	bsr cout
	ror.w #8,d4
	move.b d4,d0
	bsr hex2asc
	bsr cout				;display MUB of checksum
	ror.w #8,d0			;display MSB of checksum
	bsr cout	
	jmp $400	
* hex to ascii
* byte value in d0.b is converted to ascii in d0.w
hex2asc:
	movem.l d1,-(sp)
	move.b d0,d1
	lsr.b #4,d1		* get the high nibble first
	add.b #$30,d1
	cmp.b #'9',d1		* '0' to '9'
	bls hex2asc7
	add.b #7,d1		* or 'A' to 'F'
hex2asc7:
	lsl.w #8,d1		* put result in high byte
	move.b d0,d1		* work on the low nibble
	and.b #$F,d1		* isolate low nibble
	add.b #$30,d1
	cmp.b #'9',d1		* '0' to '9'
	bls hex2asc8
	add.b #7,d1		* or 'A' to 'F'
hex2asc8:
	move.l d1,d0		* done
	movem.l (sp)+,d1
	rts
         
cout:
;send regD0 to serial port
;bit bang at 115200
	clr.l d2			;d2 is start bit/stop bit
         move.b d2,SerData           ;start bit
	addq #1,d2		;initialize stop bit ahead of time	
         lea $ffffc,a2               ;delay using movem instruction
         moveq #7,d1
         movem d0-d5,(a2)
shift8:
	move.b d0,SerData		;bit bang Tx, D[0] connected to TX output              
         asr.b #1,d0
cout2:
         movem d0-d6,(a2)
         dbra d1,shift8 
	move.b d2,SerData		;stop bit       
         movem d0-d3,(a2)   
         rts         
         
CFbuf:
	end 0
	












*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
