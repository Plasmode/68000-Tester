@echo off
setlocal

set PATH=c:\Srec_cat;%PATH%

:build

srec_cat -generate 0x0 0x100000 --constant 0x00 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x0 0x200 MBRload.bin -binary -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x1B8 0x200 ptbl.bin -binary -offset 0x1B8 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x400 0x4000 68KMon.bin -binary -offset 0x400 -o temp.dat -binary
srec_cat temp.dat -binary -exclude 0x4000 0x8000 tutor_easy68k.bin -binary -offset 0x4000 -o temp.dat -binary

copy /b temp.dat image.img || exit /b


goto :eof
