;memory diagnostic for 68KTRST
;RAM is 128K
;memory is from $0 to $3FFFF
; stack is $3FF00-$3FFF0
; serial delay is $3FFFE
SerData	equ $ffffff13
SerStat	equ $ffffff11

	org $400
	lea $3fff0,sp		;set up stack pointer
	lea signon_,a1
signon:	
	move.b (a1)+,d0
	beq.s RAMtst
	bsr cout
	bra.s signon	
RAMtst:
	LEA ProgTop,A0		;POINT TO FIRST LOCATION IN RAM
	MOVE.L seed,D0
	move.l #($3ff00-ProgTop)/4,d3
WRAM:	
	MOVE.L D0,(A0)+
	ADDQ.L #7,D0		;A PRIME NUMBER
	subq.l #1,d3
	bne.s WRAM
* VERIFY
	LEA ProgTop,A0
	MOVE.L seed,D0
	move.l #($3ff00-ProgTop)/4,d3
VRAM:	
	MOVE.L (A0)+,D4		;READ BACK MEMORY
	CMP.L D0,D4
	BNE ERROR
	ADDQ.L #7,D0		;NEXT EXPECTED VALUE IN MEMORY
	subq.l #1,d3
	bne.s VRAM
	move.l d0,seed		;save seed value
	move.b #'O',d0
	bsr cout
	move.b #'K',d0	
	bsr cout	
	move.b #' ',d0
	bsr cout
	BRA RAMtst
ERROR:
* SPIN FOREVER 
	BRA ERROR

cout:
;send regD0 to serial port
;bit bang at 115200
;use D2,A2,D1,D0
	movem.l d0-d2/a2,-(sp)	;save registers
	clr.l d2			;d2 is start bit/stop bit
         move.b d2,SerData           ;start bit
	addq #1,d2		;initialize stop bit ahead of time	
         lea $3FFFE,a2               ;delay using movem instruction
         moveq #7,d1
         movem d0-d5,(a2)
shift8:
	move.b d0,SerData		;bit bang Tx, D[0] connected to TX output              
         asr #1,d0
cout2:
         movem d0-d6,(a2)
         dbra d1,shift8 
	move.b d2,SerData		;stop bit         
	movem.l (sp)+,d0-d2/a2 	;restore regs
         rts 
seed:	dc.l 0
signon_:	dc.b	10,13,'RAM diagnostic rev 0.2 for 256K RAM',10,13,'Program starts $400', 10,13,0        
	org (*+3)&-4		;long word alignment
ProgTop:
;top of program


	end $400







*~Font name~Courier New~
*~Font size~10~
*~Tab type~1~
*~Tab size~9~
